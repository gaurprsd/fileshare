const [
    Map, MapView, SceneView,
    Home,
    reactiveUtils,
    GraphicsLayer, SketchViewModel,
    Graphic, Polyline, BasemapGallery, Expand, Viewshed, ViewshedAnalysis
] = await window.$arcgis.import([
    "@arcgis/core/Map.js",
    "@arcgis/core/views/MapView.js",
    "@arcgis/core/views/SceneView.js",
    "@arcgis/core/widgets/Home.js",
    "@arcgis/core/core/reactiveUtils.js",
    "@arcgis/core/layers/GraphicsLayer.js",
    "@arcgis/core/widgets/Sketch/SketchViewModel.js",
    "@arcgis/core/Graphic.js",
    "@arcgis/core/geometry/Polyline.js",
    "@arcgis/core/widgets/BasemapGallery.js",
    "@arcgis/core/widgets/Expand.js",
    "@arcgis/core/analysis/Viewshed.js",
    "@arcgis/core/analysis/ViewshedAnalysis"
]);


//--- Base map + graphic layers for each view ---//
const map = new Map({
    basemap: "satellite",
    ground: "world-elevation",
});


const graphicsLayer2D = new GraphicsLayer();
const graphicsLayer3D = new GraphicsLayer();
map.addMany([graphicsLayer2D, graphicsLayer3D]);

const view1 = new SceneView({
    container: "view1Div",
    map,

    qualityProfile: "high"
});

const view2 = new MapView({
    container: "view2Div",
    map,
    constraints: { snapToZoom: false }
});

view1.when(() => view1.graphics.add(graphicsLayer3D));
view2.when(() => view2.graphics.add(graphicsLayer2D));

//--- View Synchronization---//

const views = [view1, view2];
let active;
const sync = (source) => {
    if (!active || !active.viewpoint || active !== source) return;
    for (const view of views) {
        if (view !== active) {
            const vp = active.viewpoint.clone();
            const lat = active.center.latitude;
            const factor = Math.cos((lat * Math.PI) / 180.0);
            vp.scale *= active.type === "3d" ? factor : 1 / factor;
            view.viewpoint = vp;
        }
    }
};
for (const view of views) {
    reactiveUtils.watch(() => [view.interacting, view.viewpoint], ([interacting, vp]) => {
        if (interacting) {
            active = view;
            sync(active);
        }
        if (vp) sync(view);
    });
}
//--- Home widget to reset the views---//

const homeBtn = new Home({
    view: view1
});
view1.ui.add(homeBtn, "top-left");

homeBtn.go = async () => {
    const homeViewpoint = {
        targetGeometry: {
            type: "point",
            x: 0,
            y: 0,
            spatialReference: { wkid: 4326 }
        },
        scale: 50000000
    };

    await Promise.all([
        view1.goTo(homeViewpoint),
        view2.goTo(homeViewpoint)
    ]);
};

//--- BasemapGallery---//

const basemapGallery3D = new BasemapGallery({
    view: view1
});

const basemapExpand3D = new Expand({
    view: view1,
    content: basemapGallery3D,
    expanded: false,
    group: "top-right"
});

view1.ui.add(basemapExpand3D, "top-right");

const view3D = view1;

//--- SketchViewModel for the polyline ---//

let sketch;
const polylineSymbol = {
    type: "simple-line",
    color: "red",
    width: 3
};

function setupSketch(view) {
    if (sketch) sketch.destroy();

    sketch = new SketchViewModel({
        view,
        layer: view === view2 ? graphicsLayer2D : graphicsLayer3D,
        defaultUpdateOptions: {
            tool: "reshape",
            enableRotation: false,
            enableScaling: false
        },
        elevationInfo: {
            mode: "relative-to-ground",
        },
        defaultCreateOptions: {
            hasZ: false
        },
        polylineSymbol
    });

    sketch.on("create", (event) => {
        if (event.state === "complete") {
            const geometry = event.graphic.geometry;
            const path = geometry.paths[0];
            const interpolatedPoints = interpolatePoints(path, 15, 500);

            pointsRef.current.length = 0;
            pointsRef.current.push(...interpolatedPoints);

            handleGraphicsUpdateHandler(); 

            const flatGeometry2D = flattenZValues(geometry);
            add2DGraphic(flatGeometry2D);
        }
    });
}

//Draw Button
const drawBtn = document.getElementById("drawBtn");
const viewSelect = document.getElementById("viewSelect");

drawBtn.addEventListener("click", () => {
    let currentView;
    const selected = viewSelect.value;
    if (selected === "3d" || selected === "both") {
        currentView = view1; 
    } else {
        currentView = view2;
    }
    setupSketch(currentView);
    sketch.create("polyline");
});

//Dropdown to toggle visible views
viewSelect.addEventListener("change", (e) => {
    const value = e.target.value;
    const view1Div = document.getElementById("view1Div");
    const view2Div = document.getElementById("view2Div");

    if (value === "2d") {
        view1Div.classList.add("hidden");
        view2Div.classList.remove("hidden");
        view2Div.style.width = "100%";
    } else if (value === "3d") {
        view1Div.classList.remove("hidden");
        view2Div.classList.add("hidden");
        view1Div.style.width = "100%";
    } else {
        view1Div.classList.remove("hidden");
        view2Div.classList.remove("hidden");
        view1Div.style.width = "50%";
        view2Div.style.width = "50%";
    }
});

//Clear button
const clearBtn = document.getElementById("clearBtn");

clearBtn.addEventListener("click", () => {

    graphicsLayer2D.removeAll();
    graphicsLayer3D.removeAll();
    view1.graphics.removeAll();
    view2.graphics.removeAll();
    if (symbolGraphicRef) symbolGraphicRef.current = null;
    if (symbol2DGraphicRef) symbol2DGraphicRef.current = null;


    if (viewshedAnalysis && dynamicViewshed) {
        viewshedAnalysis.viewsheds.remove(dynamicViewshed);
        dynamicViewshed = null;
    }

    if (viewshedAnalysis && view1.analyses.includes(viewshedAnalysis)) {
        view1.analyses.remove(viewshedAnalysis);
        viewshedAnalysis = null;
    }

    if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
    }

    isPlaying = false;
    isPlayingR = false;
    pausedProgress = 0;
    if (playPauseBtn) playPauseBtn.innerHTML = `<span class="esri-icon-play"></span>`;
    if (reverseBtn) reverseBtn.innerHTML = `<span class="esri-icon-reverse"></span>`;
});

// --- Button Handlers Attachment ---//
const playPauseBtn = document.getElementById("playPauseBtn");
const reverseBtn = document.getElementById("reverseBtn");
const speedSlider = document.getElementById("speedSlider");
const speedValueDisplay = document.getElementById("speedValue");
const speedContainer = document.getElementById("SpeedContainer");
const toggleSpeedBtn = document.getElementById("toggleSpeedBtn");

if (playPauseBtn) playPauseBtn.addEventListener("click", handlePlayPauseClick);
if (reverseBtn) reverseBtn.addEventListener("click", handleReverseClick);
if (toggleSpeedBtn) toggleSpeedBtn.addEventListener("click", toggleSpeed);
if (speedSlider) speedSlider.addEventListener("input", handleSpeedChange);

let altitudeOffset = 10;

const altitudeSlider = document.getElementById("altitudeSlider");
const altitudeValue = document.getElementById("altitudeValue");

altitudeSlider.addEventListener("input", (e) => {
    altitudeOffset = parseInt(e.target.value, 10);
    altitudeValue.textContent = altitudeOffset;
});

let animationRef = { current: null };
let startTimeRef = { current: null };
let pausedProgress = 0;
let isPlaying = false;
let isPlayingR = false;
let firstDirection = null;
let direction = 'forward';
let symbolGraphicRef = { current: null };
let symbol2DGraphicRef = { current: null };
const pointsRef = { current: [] };
let speed = 1;
const animationDurationRef = { current: 300000 };
const dynamicHeight = 500;

function toggleSpeed() {
    if (speedContainer.style.display === "flex") {
        speedContainer.style.display = "none";
    } else {
        speedContainer.style.display = "flex";
    }
}
function handleSpeedChange(event) {
    const newSpeed = parseFloat(event.target.value);
    speed = newSpeed;
    if (speedValueDisplay) speedValueDisplay.textContent = newSpeed.toFixed(2);

    if (isPlaying || isPlayingR) {
        const elapsedTime = Date.now() - startTimeRef.current;
        const adjustedDuration = animationDurationRef.current / newSpeed;
        const currentProgress = elapsedTime / adjustedDuration;

        if (animationRef.current) cancelAnimationFrame(animationRef.current);
        pausedProgress = isPlaying
            ? Math.min(pausedProgress + currentProgress, 1)
            : Math.max(pausedProgress - currentProgress, 0);

        startTimeRef.current = Date.now();
        startAnimation(pausedProgress, direction);
    }
}

function interpolatePoints(path, distanceBetweenPoints, zOffset) {
    const points = [];
    for (let i = 0; i < path.length - 1; i++) {
        const start = path[i];
        const end = path[i + 1];
        const segmentLength = Math.hypot(end[0] - start[0], end[1] - start[1]);
        const numberOfPoints = Math.floor(segmentLength / distanceBetweenPoints);
        for (let j = 0; j <= numberOfPoints; j++) {
            const t = j / numberOfPoints;
            points.push([
                start[0] + t * (end[0] - start[0]),
                start[1] + t * (end[1] - start[1]),
                zOffset
            ]);
        }
    }
    return points;
}

function flattenZValues(geometry) {
    const paths = geometry.paths.map(path =>
        path.map(vertex => [vertex[0], vertex[1], 0])
    );
    return new Polyline({
        paths: paths,
        spatialReference: geometry.spatialReference
    });
}

function add2DGraphic(geometry) {
    const polylineGraphic2D = new Graphic({
        geometry: geometry,
        symbol: {
            type: "simple-line",
            color: [255, 0, 0, 255],
            width: 2,
            style: "solid"
        }
    });
    view2.graphics.add(polylineGraphic2D);
}
//---VIEWSHED ---//

let viewshedAnalysis, dynamicViewshed;

function initializeViewshed(view) {

    viewshedAnalysis = new ViewshedAnalysis();
    view.analyses.add(viewshedAnalysis);

    dynamicViewshed = new Viewshed({
        observer: {
            type: "point",
            spatialReference: view.spatialReference,
            //   x: 0,
            //   y: 0,
            //   z: 0
        },
        farDistance: 1000,
        // tilt: 85,
        // heading: 0,
        horizontalFieldOfView: 360,
        verticalFieldOfView: 60
    });

    viewshedAnalysis.viewsheds.add(dynamicViewshed);
}
view1.when(() => initializeViewshed(view1));
//--- Animation logic starts here ---//

const startAnimation = async (initialProgress = 0, newDirection = 'forward') => {
    if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
    }

    if (pointsRef.current.length === 0) return;

    if (!firstDirection) {
        firstDirection = newDirection;
    }

    let totalProgress = initialProgress;
    const previousDirection = firstDirection;

    if (newDirection === 'reverse') {
        totalProgress = Math.max(1 - pausedProgress, 0);
    } else if (previousDirection === 'reverse' && newDirection === 'forward') {
        totalProgress = pausedProgress;
    } else {
        totalProgress = Math.min(initialProgress, 1);
    }

    if (!symbolGraphicRef.current || !symbol2DGraphicRef.current) {
        addSymbols({
            type: 'point',
            x: pointsRef.current[0][0],
            y: pointsRef.current[0][1],
            z: (pointsRef.current[0][2] || 0),
            spatialReference: view1.spatialReference,
        });
    }

    const adjustedAnimationDuration = animationDurationRef.current / speed;
    startTimeRef.current = Date.now();

    const totalDistance = pointsRef.current.reduce((acc, point, index) => {
        if (index > 0) {
            const prevPoint = pointsRef.current[index - 1];
            acc += Math.sqrt(
                Math.pow(point[0] - prevPoint[0], 2) +
                Math.pow(point[1] - prevPoint[1], 2) +
                Math.pow((point[2] || 0) - (prevPoint[2] || 0), 2)
            );
        }
        return acc;
    }, 0);

    const animate = () => {
        const elapsedTime = Date.now() - startTimeRef.current;
        let currentProgress = (elapsedTime / adjustedAnimationDuration) + totalProgress;

        if (newDirection === 'reverse') {
            currentProgress = Math.max(1 - currentProgress, 0);
        } else {
            currentProgress = Math.min(currentProgress, 1);
        }

        const easeInOutQuad = (t) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t);
        const easedProgress = easeInOutQuad(currentProgress);
        const currentDistance = easedProgress * totalDistance;

        let traveledDistance = 0;

        for (let index = 0; index < pointsRef.current.length - 1; index++) {
            const currentPoint = pointsRef.current[index];
            const nextPoint = pointsRef.current[index + 1];

            const segmentDistance = Math.sqrt(
                Math.pow(nextPoint[0] - currentPoint[0], 2) +
                Math.pow(nextPoint[1] - currentPoint[1], 2) +
                Math.pow((nextPoint[2] || 0) - (currentPoint[2] || 0), 2)
            );

            if (traveledDistance + segmentDistance >= currentDistance) {
                const remainingDistance = currentDistance - traveledDistance;
                const t = remainingDistance / segmentDistance;

                const interpolatedPoint3D = {
                    type: 'point',
                    x: currentPoint[0] + t * (nextPoint[0] - currentPoint[0]),
                    y: currentPoint[1] + t * (nextPoint[1] - currentPoint[1]),
                    z: (currentPoint[2] || 0) + t * ((nextPoint[2] || 0) - (currentPoint[2] || 0)),
                    spatialReference: view1.spatialReference,
                };

                view1.map.ground.queryElevation(interpolatedPoint3D).then((result) => {
                    const groundPoint = result.geometry;

                    // Setting up of viewshed 
                    if (!viewshedAnalysis || !dynamicViewshed) {
                        initializeViewshed(view1);
                    }

                    // if (dynamicViewshed) {
                    //     const observer = groundPoint.clone();
                    //     observer.z += 10; // buffer above ground 

                    //     dynamicViewshed.observer = observer;
                    //     dynamicViewshed.heading = view1.camera.heading;
                    //     dynamicViewshed.tilt = view1.camera.tilt;
                    // }
                    if (dynamicViewshed) {
                        const observer = groundPoint.clone();
                        observer.z += altitudeOffset; // Use slider-controlled offset
                        dynamicViewshed.observer = observer;
                        dynamicViewshed.heading = view1.camera.heading;
                        dynamicViewshed.tilt = view1.camera.tilt;
                    }


                    if (symbolGraphicRef.current) {
                        symbolGraphicRef.current.geometry = groundPoint;
                    }

                    if (symbol2DGraphicRef.current) {
                        const interpolatedPoint2D = {
                            type: 'point',
                            x: groundPoint.x,
                            y: groundPoint.y,
                            spatialReference: view2.spatialReference,
                        };
                        symbol2DGraphicRef.current.geometry = interpolatedPoint2D;
                    }

                    const userZoom = view1.camera.position.z;
                    const height = groundPoint.z + dynamicHeight;
                    const userTilt = view1.camera.tilt;
                    const heading = view1.camera.heading;

                    const camera = view1.camera.clone();
                    camera.position = { ...interpolatedPoint3D, z: groundPoint.z + dynamicHeight };
                    //camera.position = { ...interpolatedPoint3D, z: groundPoint.z + altitudeOffset }; // 👈 Also here

                    camera.heading = heading;
                    camera.target = groundPoint;
                    view1.camera = camera;
                    view1.goTo({
                        target: camera.target,
                        tilt: userTilt,
                        heading: heading,
                    }, { animate: false });
                });

                break;
            }

            traveledDistance += segmentDistance;
        }

        if (currentProgress > 0 && currentProgress < 1) {
            animationRef.current = requestAnimationFrame(animate);
        } else {
            pausedProgress = currentProgress;
            isPlaying = false;
            isPlayingR = false;
            if (playPauseBtn) {
                playPauseBtn.innerHTML = `<span class="${isPlaying ? 'esri-icon-pause' : 'esri-icon-play'}" aria-hidden="true"></span>`;

            }
            if (reverseBtn) {
                reverseBtn.innerHTML = `<span class="${isPlayingR ? 'esri-icon-pause' : 'esri-icon-reverse'}" aria-hidden="true"></span>`;
            }
        }
    };

    animationRef.current = requestAnimationFrame(animate);

    // if (newDirection === 'forward' && playPauseBtn) playPauseBtn.textContent = "Pause";
    // if (newDirection === 'reverse' && reverseBtn) reverseBtn.textContent = "Pause Reverse";

};

function addSymbols(point) {
    symbolGraphicRef.current = new Graphic({
        geometry: point,
        symbol: {
            type: "point-3d",
            symbolLayers: [{
                type: "object",
                resource: { href: "https://raw.githubusercontent.com/Damayantee15/drone-model/main/file-1592658408798.glb" },
                height: 20, width: 20, depth: 10, anchor: "center"
            }]
        },
        elevationInfo: { mode: "relative-to-ground", offset: 2 }
    });
    view1.graphics.add(symbolGraphicRef.current);

    symbol2DGraphicRef.current = new Graphic({
        geometry: point,
        symbol: {
            type: "picture-marker",
            url: "https://raw.githubusercontent.com/Damayantee15/drone-model/main/drone.svg",
            width: "32px",
            height: "32px"
        }
    });
    view2.graphics.add(symbol2DGraphicRef.current);
}
//--- Function for forward play/pause button---//

function handlePlayPauseClick() {
    if (isPlaying) {
        if (animationRef.current) {
            cancelAnimationFrame(animationRef.current);
            animationRef.current = null;
        }
        const elapsedTime = Date.now() - startTimeRef.current;
        const currentProgress = elapsedTime / (animationDurationRef.current / speed);
        pausedProgress = Math.min(pausedProgress + currentProgress, 1);
        isPlaying = false;
        if (playPauseBtn) {
            playPauseBtn.innerHTML = `<span class="${isPlaying ? 'esri-icon-pause' : 'esri-icon-play'}" aria-hidden="true"></span>`;
        }
    } else {
        startTimeRef.current = Date.now();
        direction = 'forward';
        startAnimation(pausedProgress, direction);

        isPlaying = true;
        isPlayingR = false;
        if (playPauseBtn) {
            playPauseBtn.innerHTML = `<span class="${isPlaying ? 'esri-icon-pause' : 'esri-icon-play'}" aria-hidden="true"></span>`;

        }
        if (reverseBtn) {
            reverseBtn.innerHTML = `<span class="${isPlayingR ? 'esri-icon-pause' : 'esri-icon-reverse'}" aria-hidden="true"></span>`;
        }
    }
}
//--- Function for reverse play/pause button---//
function handleReverseClick() {
    if (isPlayingR) {
        if (animationRef.current) {
            cancelAnimationFrame(animationRef.current);
            animationRef.current = null;
        }
        const elapsedTimeR = Date.now() - startTimeRef.current;
        const currentProgressR = elapsedTimeR / (animationDurationRef.current / speed);
        pausedProgress = Math.max(pausedProgress - currentProgressR, 0);
        isPlayingR = false;
        if (reverseBtn) {
            reverseBtn.innerHTML = `<span class="${isPlayingR ? 'esri-icon-pause' : 'esri-icon-reverse'}" aria-hidden="true"></span>`;
        }
    } else {
        startTimeRef.current = Date.now();
        direction = 'reverse';
        startAnimation(pausedProgress, direction);
        isPlayingR = true;
        isPlaying = false;
        if (reverseBtn) {
            reverseBtn.innerHTML = `<span class="${isPlayingR ? 'esri-icon-pause' : 'esri-icon-reverse'}" aria-hidden="true"></span>`;

        }
        if (playPauseBtn) {
            playPauseBtn.innerHTML = `<span class="${isPlaying ? 'esri-icon-pause' : 'esri-icon-play'}" aria-hidden="true"></span>`;
        }
    }
}

function handleGraphicsUpdateHandler() {
    if (isPlaying) {
        startAnimation(pausedProgress, 'forward');
    }
    if (isPlayingR) {
        startAnimation(pausedProgress, 'reverse');
    }
}





