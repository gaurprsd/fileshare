require([
  "esri/config",
  "esri/WebMap",
  "esri/Map",
  "esri/views/MapView",
  "esri/views/SceneView",
  "esri/layers/ElevationLayer"
], function (esriConfig, WebMap, Map, MapView, SceneView, ElevationLayer) {

  esriConfig.portalUrl = "https://dss.bsf.gov.in/gisportal";

  const toggleBtn = document.getElementById("toggleViewBtn");
  const mapContainer = "esriMap";
  let is3D = false;

  // 2D WebMap
  const map2D = new WebMap({
    portalItem: {
      id: "f2e9b762544d4b2aa665466ab30d8001"
    }
  });

  // 3D Elevation Map
  const map3D = new Map({
    basemap: "topo",
    ground: {
      navigationConstraint: { type: "none" },
      layers: []
    }
  });

  map3D.ground.layers.add(
    new ElevationLayer({
      url: "https://dss.bsf.gov.in/gisserver/rest/services/SRTM_Scene_WEL/ImageServer"
    })
  );

  // 2D View
  const view2D = new MapView({
    container: mapContainer,
    map: map2D
  });

  // 3D View
  const view3D = new SceneView({
    container: null,
    map: map3D,
    environment: {
      lighting: {
        directShadowsEnabled: true,
        date: new Date()
      },
      atmosphereEnabled: true,
      starsEnabled: true
    }
  });

  // Go to initial location in 3D view
  view3D.when(() => {
    view3D.goTo({
      target: {
        spatialReference: { wkid: 4326 },
        center: [77.2, 28.6], // New Delhi
        scale: 500000
      }
    });
  });

  // Toggle handler
  toggleBtn.addEventListener("click", () => {
    const fromView = is3D ? view3D : view2D;
    const toView = is3D ? view2D : view3D;

    toView.container = mapContainer;
    toView.viewpoint = fromView.viewpoint.clone();
    fromView.container = null;

    toggleBtn.textContent = is3D ? "Switch to 3D" : "Switch to 2D";
    is3D = !is3D;
  });

  window.addEventListener("beforeunload", () => {
    view2D.destroy();
    view3D.destroy();
  });
});
